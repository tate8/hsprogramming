import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class SpaceGame extends PApplet {

// SpaceGame | Dec 2020
// Tate Larkin
// TODO: Project Setup


SpaceShip s1;
ArrayList<PowerUp> pups;
ArrayList<Laser> lasers;
ArrayList<Enemy> enemies;
ArrayList<EnemyLaser> elasers;
ArrayList<Rock> rocks;
ArrayList<Star> stars;
Timer timer, puTimer, enemyTimer;
int pass, enemyHealth;
boolean play;
String ticText;




public void setup() {
  
  //laser1 = new SoundFile(this, "asteroids-ship-shoot.wav");
  s1 = new SpaceShip(0xffC54BE8);
  lasers = new ArrayList();
  rocks = new ArrayList();
  stars = new ArrayList();
  elasers = new ArrayList();
  enemies = new ArrayList();
  pups = new ArrayList();
  timer = new Timer(PApplet.parseInt(random(1000, 5000)));
  timer.start();
  enemyTimer = new Timer(5000);
  enemyHealth = 100;

  pass = 0;
  play = false;
  puTimer = new Timer(5000);
  puTimer.start();
}

public void draw() {
  noCursor();
  if (!play) {
    startScreen();
  } else {
    background(0);

    stars.add(new Star(PApplet.parseInt(random(width)), 0));

    for (int i = 0; i < stars.size(); i++) {
      Star star = stars.get(i);
      star.display();
      star.move();
      if (star.reachedBottom()) {
        stars.remove(star);
      }
    }

    if (puTimer.isFinished()) {
      pups.add(new PowerUp(PApplet.parseInt(random(width)), height-790));
      puTimer.start();
    }
    for (int i = 0; i<pups.size(); i++) {
      PowerUp pu = pups.get(i);
      pu.move();
      pu.display();
      if (s1.puIntersect(pu)) {
        if (pu.pu == 0) {
          s1.ammo+=100;
        } else if (pu.pu == 1) {
          s1.health+=100;
        }
        pups.remove(pu);
      }
      if (pu.reachedBottom()) {
        pups.remove(pu);
      }
    }

    if (timer.isFinished()) {
      rocks.add(new Rock(PApplet.parseInt(random(width)), -50));
      timer.start();
    }

    for (int i = 0; i < rocks.size(); i++) {
      Rock rock = rocks.get(i);
      rock.display();
      rock.move();
      // rock vs ship collision
      if (s1.rockIntersection(rock)) {
        s1.health -= rock.health;
        rocks.remove(rock);
        s1.score -= 25;
      }
      if (rock.reachedBottom()) {
        pass++;
        rocks.remove(rock);
      }
    }
    s1.display(mouseX, mouseY);

    if (enemyTimer.isFinished()) {
      enemies.add(new Enemy(0, 80, PApplet.parseInt(random(500, 1500)), enemyHealth));
      enemyTimer.start();
    }

    for (int i = 0; i<enemies.size(); i++) {
      Enemy enemy = enemies.get(i);
      enemy.move();
      enemy.display();
      if (s1.shipIntersect(enemy)) {
        s1.health-=10;
        enemies.remove(enemy);
      }
      if (enemy.isFinished()) {
        elasers.add(new EnemyLaser(enemy.x, enemy.y));
        enemy.start();
      }
     
    }
    
    for (int i = 0; i<lasers.size(); i++) {
      Laser laser = (Laser) lasers.get(i);
      laser.fire();
      laser.display();

    for (int l = elasers.size()-1; l>=0; l--) {
      EnemyLaser elaser = (EnemyLaser) elasers.get(l);
      elaser.fire();
      elaser.display();
      if (s1.enemyLaserIntersect(elaser)) {
        elasers.remove(elaser);
      }
      if (elaser.reachedBottom()) {
        elasers.remove(elaser);
      }
    }
    for (int k = 0; k<enemies.size(); k++) {
        Enemy enemy = enemies.get(k);
        if (enemy.laserIntersection(laser)) {
          lasers.remove(laser);
          enemy.health-=20;
          if (enemy.health<1) {
            enemies.remove(enemy);
          }
        }
      }



    for (int m = 0; m < lasers.size(); m++) {
      Laser laser1 = lasers.get(i);
      laser1.display();
      laser1.fire();
      // detect rock collision
      for (int j = 0; j < rocks.size(); j++) {
        Rock rock = rocks.get(j);
        if (rock.laserIntersection(laser)) {
          lasers.remove(laser);
          s1.score+=5;
          rock.health-= 25;
          if (rock.health<1) {
            rocks.remove(rock);
            s1.score+= 20;
          }
        }
      }
      if (laser.reachedTop()) {
        lasers.remove(laser);
      }
    }
    infoPanel();
    s1.display(mouseX, mouseY);
    if (s1.health<1 || pass>10) {
      play = false;
      gameOver();
    }
  }
}
}
public void mousePressed() {
  if (play) {
  }
  if (s1.ammo >0) {
    lasers.add(new Laser(s1.x, s1.y));
  } else {
    s1.ammo = 0;
  }
  s1.ammo --;
}
public void startScreen() {
  background(0);
  textAlign(CENTER);
  text("Welcome!", width/2, height/2);
  text("Click to Continue . . .", width/2, height/2+20);

  if (mousePressed) {
    play = true;
  }
}
public void gameOver() {
  background(0);
  textAlign(CENTER);
  fill(222);
  text("Game Over!", width/2, height/2);
  text("Your Final Score Was: "+s1.score, width/2, height/2+20);
  noLoop();
}

public void infoPanel() {
  fill(128, 128);
  rectMode(CORNER);
  rect(0, height-50, width, 50);
  fill(255, 128);
  textSize(13);
  text("Health: "+ s1.health, 60, height-20);
  text("Lives: "+ s1.lives, 140, height-20);
  text("Ammo: "+ s1.ammo, 220, height-20);
  text("Score: "+s1.score, 300, height-20);
  if (pass > 5) {
    fill(255, 0, 0);
  }
  text("Pass: "+pass, 380, height-20);
}
class EnemyLaser {
  int x, y, speed, r; 
  int c;

  EnemyLaser(int x, int y) {
    r = 4; 
    this.x = x; 
    this.y = y; 
    speed = PApplet.parseInt(random(5, 15));    
    c = color(0xff8B3E4C);
  }

  public void fire() {
    y += speed;
  }

  public boolean reachedBottom() {
    if (y > height) { 
      return true;
    } else {
      return false;
    }
  }

  public void display() {
    fill(c);
    noStroke();
    rect(x, y, r, 8);
  }
}

class Enemy {
  int r, health, x, y, speed;
  boolean right;
  int savedTime; 
  int totalTime;

  Enemy(int x, int y, int t, int health) {
    r = 25;
    this.x = x;
    this.y = y;
    this.health = health;
    speed = 5;
    this.totalTime = t;
  }

  public void display() {
    noStroke();
    rectMode(CENTER);
    fill(0xffC10C1B);
    ellipse(x,y,45,32);
    rect(x,y+10,10,20);
  }


  public void move() {
    x += speed;
    if (x >= width|| x <= 0) {
      speed *= -1;
      y+=50;
    }
  }

  public boolean laserIntersection(Laser laser) {
    float distance = dist(x, y, laser.x, laser.y); 
    if (distance < r+ laser.radius) { 
      return true;
    } else {
      return false;
    }
  }

  public void start() {
    savedTime = millis();
  }


  public boolean isFinished() { 
    int passedTime = millis()- savedTime;
    if (passedTime > totalTime) {
      return true;
    } else {
      return false;
    }
  }
}
class Laser {
  // member variables
  int x, y, speed,radius;
  int c;

  //constructor
  Laser(int x, int y) {
    this.x = x;
    this.y = y;
    speed = 5;
    radius = 3;
    c = 0xffF00F38;
  }

  //member methods
  public void fire() {
    y-=speed;
  }

  public boolean reachedTop() {
    if (y<-3) {
      return true;
    } else {
      return false;
    }
  }

  public void display() {
    fill(c);
    noStroke();
    rectMode(CENTER);
    rect(x, y, radius, radius*2);
  }
}
class PowerUp {
  int x, y, speed, r, pu; 
  String[] puInfo = {"Ammo", "Health"};

  PowerUp(int x, int y) {
    r = 40; 
    this.x = x;
    this.y = y;
    speed = PApplet.parseInt(random(2, 6));
    pu = PApplet.parseInt(random(4));
  }

  public void move() {
    y += speed;
  }

  public boolean reachedBottom() {
    if (y > height + r*4) { 
      return true;
    } else {
      return false;
    }
  }

  public void display() {
    noStroke();
    switch(pu) {
    case 0:
      fill(255,0,0);
      ellipse(x, y, r, r);
      fill(255);
      textSize(9);
      textAlign(CENTER);
      text(puInfo[0], x, y);
      break;
    case 1:
      fill(0,255,0);
      ellipse(x, y, r, r);
      fill(255);
      textSize(9);
      textAlign(CENTER);
      text(puInfo[1], x, y);
      break;
    }
  }
}
class Rock {
  // member variables
  int x, y, dia, health, speed, radius;
  char displayMode;
  int c;

  //constructor
  Rock(int x, int y) {
    this.x = x;
    this.y = y;
    y = 0;
    dia =50;
    health = 50;
    speed = PApplet.parseInt(random(2, 6));
    displayMode = '1';
    c = 0xff48360F;
    radius = 30;
  }
  
  // laser vs rock collision
  public boolean laserIntersection(Laser laser) {
    float distance = dist(x, y, laser.x, laser.y);
    if (distance < radius + laser.radius) {
      return true;
    } else {
      return false;
    }
  }
  
  

  public boolean reachedBottom() {
    if (y>height) {
      return true;
    } else {
      return false;
    }
  }

  public void move() {
    y+=speed;
  }


  //member methods
  public void display() {
    fill(0xff645C4F);
    ellipse(x, y, dia, dia);
  }
}
class SpaceShip {
  // member variable
  int r, x, y, health, ammo, lives, radius, score;
  char displayMode;
  int c1;


  // constructor
  SpaceShip(int c1) {
    x = 0;
    r=25;
    y = 0;
    health = 200;
    ammo = 50;
    lives = 3;
    displayMode = '1';
    this.c1 = c1;
    radius = 30;
    score = 0;
  }
  //rock vs ship collision
  public boolean rockIntersection(Rock rock) {
    float distance = dist(x, y, rock.x, rock.y);
    if (distance < radius + rock.radius) {
      return true;
    } else {
      return false;
    }
  }
  // ship vs. powerups collision
  public boolean puIntersect(PowerUp pu) {
    float distance = dist(x, y, pu.x, pu.y); 
    if (distance < radius + pu.r) { 
      return true;
    } else {
      return false;
    }
  }

  public boolean enemyLaserIntersect(EnemyLaser elaser) {
    float distance = dist(x, y, elaser.x, elaser.y); 
    if (distance < r + elaser.r) { 
      return true;
    } else {
      return false;
    }
  }

  public boolean shipIntersect(Enemy enemy) {
    float distance = dist(x, y, enemy.x, enemy.y); 
    if (distance < r + enemy.r) { 
      return true;
    } else {
      return false;
    }
  }



  //member methods
  public void display(int x, int y) {
    this.x=x;
    this.y=y;
    if (displayMode == '1') {
      noStroke();
      rectMode(CENTER);
      fill(0xff1D520D);
      rect(x+20, y+20, 10, 10);
      rect(x-20, y+20, 10, 10);
      stroke(255);
      line(x, y-30, x, y-55);
      //line(x+25, y-5, x+25, y+15);
      //line(x-25, y-5, x-25, y+15);
      noStroke();
      fill(0xff22670E);
      triangle(x, y-20, x+40, y+20, x-40, y+20);
      fill(0xff155503);
      ellipse(x, y-10, 20, 80);
    }
  }
}
class Star {
  // member variables
  int x, y,speed,dia;
  int c;

  //constructor
  Star(int x, int y) {
    this.x=x;
    this.y=y;
    speed = PApplet.parseInt(random(1,5));
    dia = PApplet.parseInt(random(1,4));
    c = color(random(160,255));
  }
  public boolean reachedBottom() {
    if (y>height) {
      return true;
    } else {
      return false;
    }
  }

  public void move() {
    y+=speed;
  }
  
  //member methods
  public void display() {
    fill(c);
    noStroke();
    ellipse(x,y,dia,dia);
  }
}
// Example 10-5: Object-oriented timer
// by Daniel Shiffman

class Timer {

  int savedTime; // When Timer started
  int totalTime; // How long Timer should last

  Timer(int tempTotalTime) {
    totalTime = tempTotalTime;
  }

  // Starting the timer
  public void start() {
    // When the timer starts it stores the current time in milliseconds.
    savedTime = millis();
  }

  // The function isFinished() returns true if 5,000 ms have passed. 
  // The work of the timer is farmed out to this method.
  public boolean isFinished() { 
    // Check how much time has passed
    int passedTime = millis()- savedTime;
    if (passedTime > totalTime) {
      return true;
    } else {
      return false;
    }
  }
}
  public void settings() {  size(500, 800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "SpaceGame" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
