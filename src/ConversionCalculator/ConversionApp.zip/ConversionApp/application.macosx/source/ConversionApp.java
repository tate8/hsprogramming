import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class ConversionApp extends PApplet {

public void setup() {
  
}

public void draw() {
  background(200);
  textSize(27);
  text("Conversion App", 330, 25);
  textSize(16);
  text("Tate Larkin | 2020", 360, 50);
  textSize(13);
  text("Find the approximate conversion of miles to kilometers by hovering over the amount of miles you wish to convert.",55,70);


  strokeWeight(2);
  for (int i = 0; i<801; i+=80) {
    line(i, 195, i, 205);
  }
  for (int ii = 0; ii<801; ii+=80) {
    textSize(10);
    text("Mile: "+ii/80, ii-17, 220);
  }

  strokeWeight(1);
  line(0, height/2, width, height/2);
  ellipse(mouseX, height/2, 5, 5);
  convertMiles(mouseX);
}
public void convertMiles(float kilos) {
  kilos = (kilos/80)*(1.609f);
  if (kilos <20) {
    textSize(12);
    text("In KM: " +kilos, mouseX, 190);
  }
}
  public void settings() {  size(830, 400); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "ConversionApp" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
