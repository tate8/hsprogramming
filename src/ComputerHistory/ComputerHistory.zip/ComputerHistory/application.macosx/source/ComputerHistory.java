import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class ComputerHistory extends PApplet {


//Tate Larkin | Computer Timeline
//Sept. 15, 2020
boolean hover = false;

public void setup() {
  
}

public void draw() {
  background(175);
  println(hover);
  drawRef();
  histEvent(175, 200, 100, 25, "Analytical Engine - 1833", "This was the first mechanical computer to be made. The design was thought of by Charles Babbage, an English mechanical engineer. This computer could store up to 1,000 numbers of 40 decimal digits. It was the first design for a general-purpose computer, in modern terms, it was Turing-complete. This computer was able to perform arithmetic operations, comparisons, and square roots. Because of its technology, the Analytical Engine was described to be a century ahead of its time.", true);
  histEvent(175, 275, 100, 25, "Z3 - 1941", "The Z3 was an improved design of the Z1 and Z2. Created by Konrad Zuse, this electromechanical computer was the world's first, fully programmable, and fully automatic digital computer.It used the binary system which was simpler and meant that these machines were much easier to produce then their predecessors as well as usually being more reliable. This machine was also Turing-complete which was still revolutionary for the time.", false);
  histEvent(325, 275, 100, 25, "Manchester Baby - 1948", "The Manchester Baby was the world's first electronic stored-program computer. It was built by Freddia Williams and Tom Kilburn. It used secondary emission to store electronic binary data, it was the first working machine that had all the parts of a modern electric computer. It had a memory of 32 words, and while it wasn't very fast at running calculations it was revolutionary in the fact that it could store data electronically.", false);
  histEvent(325, 200, 100, 25, "Colossus - 1944", "Developed by Tommy Flowers, based on the design of Heath Robinson, the Colossus was a machine built to aid in code breaking. Colossus was the first electronic digital programmable computer. It was able to use boolean logic, but was not Turing-complete. It accepted input data in the form of photoelectric reading of a paper tape with an enciphered message on it. This machine and others were vital during World War two, they gave the Allies valuable information by decrypting Germain telegraphic messages.", true);
  histEvent(475, 200, 100, 25, "Ferranti Mark 1 - 1951", "The Ferranti Mark 1 was built by Ferranti and was based off of an earlier computer, the Manchester Mark 1. It was an improvement from this computer because it had more storage, a faster multiplier, and additional instructions. A more advanced model, the Mark 1 Star was built based off of it, and seven of these were delivered around the world.", true);
  histEvent(475, 275, 100, 25, "Harwell CADET - 1955", "The Harwell CADET was a distinguishable transistor computer built by the electronics division at Harwell. It was built with bipolar transistors, which replaced vacuum tubes because they were small and faster than the latter. It had a 64-kilobyte magnetic drum memory with a low clock speed for increased simplicity. This addition of bipolar transistors was extremely monumental, allowing computers to become even smaller.", false);
  histEvent(625, 275, 100, 25, "Altair 8800 - 1975", "The Altair 8800 was the first commercially available microcomputer kit. It was based off of earlier systems like the Intel 8080 which used microprocessors, which as the name suggests were processors of never before seen small size. Despite having little DRAM, it was very popular, having a few hundred sales in the first year. The P6060 followed this computer and although it was more advanced, it didn't have as much popularity as the Altair. Now, just about all computers have microprocessors, so this advancement was very important.", false);
  histEvent(625, 200, 100, 25, "Atlas - 1962", "The Atlas, built as a joint development between the University of Manchester, Ferranti, and Plessey, was recognized as one of the world's first supercomputers. It was also recognized as the most powerful computer in the world at the time. It used discrete germanium transistors, and pioneered the Atlas Supervisor, the first modern operating system.", true);
}


public void drawRef() {
  //title text
  line(100, 250, 800, 250);
  fill(0, 102, 153, 204);
  textSize(25);
  text("Historic Computer Systems", 290, 40);

  //timeline
  strokeWeight(1);
  stroke(0);
  line(100, 250, 800, 250);
//end marks
line(100,225,100,275);
line(800,225,800,275);
strokeWeight(1);
textSize(12);
fill(0);
text("1820",85,290);
text("2000", 785, 290);
  //descriptive text
  textSize(15);
  text("Tate | 2020", 400, 60);
  textSize(11);
  text("Significant computers from the 19th and 20th century. Hover for details", 255, 75);
  
  //zigzag
  line(205, 250, 210,245);
  line(210,245,215,255);
  line(215,255,220,245);
  line(220, 245, 225, 255);
  line(225, 255, 230, 250);
}

public void histEvent(int x, int y, int w, int h, String title, String description, boolean top) {
  //detect the location of the mouse
  hover = (mouseX > x && mouseX < x+w && mouseY > y && mouseY < y+h);
  //draw a rectangle
  strokeWeight(1);
  if (hover == true) {
    fill(150);
  } else {
    fill(200);
  }

  rect(x, y, w, h, 5);
  //draw the title for the rectangle
  fill(0);
  textAlign(LEFT);
  textSize(8);
  text(title, x+3, y+16);
  if (hover == true) {
    textSize(14);
    text(description, 10, 90,850,315);
  }
  //draw the onneting line
  stroke(0);
  if (top == true) {
    line(x+50, y+25, x+20, y+50);
  } else {
    line(x+50, y, x+85, y-25);
  }
}
  public void settings() {  size(900, 400); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "ComputerHistory" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
