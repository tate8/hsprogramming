#include <iostream>
#include <vector>
#include <algorithm>
#include <random>
#include <chrono>
#include <thread>
#include <cstdlib>
#include <fstream>
using namespace std;

string 
  one = "What is the best color?:",
  two = "What is the best food?:",
  three = "What is the best animal?:",
  four = "What is the best weather?:",
  five = "What is the best game?:",
  six = "What is the fastest car?:",
  seven = "What is the fastest fish?:",
  eight = "What is the fastest bird?:",
  nine = "What is the fastest plane?:",
  ten = "What is the fastest boat?:",
  answer;
int x = 5;
int main() {
  vector<string> questions;
  questions.push_back(one);
  questions.push_back(two);
  questions.push_back(three);
  questions.push_back(four);
  questions.push_back(five);
  questions.push_back(six);
  questions.push_back(seven);
  questions.push_back(eight);
  questions.push_back(nine);
  questions.push_back(ten);

  ofstream o("answers.txt");
  for (int i;i<11;i++){
  vector<string> out;
    size_t nelems = 1;
    sample(
        questions.begin(),
        questions.end(),
        back_inserter(out),
        nelems,
        mt19937{random_device{}()}
    );
    for (auto i : out)
        cout << i << endl;
        cin >> answer;
  
  ofstream ofs;
  ofs.open ("answers.txt", ofstream::app);
  ofs << answer << endl;
  ofs.close();

  }
  ofstream endofs;
  endofs.open("answers.txt", ofstream::app);
  endofs << "\n-----End of Answers----\n";
  cout << "Your answers have been recorded..." << endl;

}