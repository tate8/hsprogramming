import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class FinishCalculator extends PApplet {

//2020 Calculator for Porgramming I

//Tate Larkin | Nov 2020





Button[] numButtons = new Button[10];

Button[] opButtons= new Button[11];

String dVal, op;

boolean left;

float l, r, result;

public void settings() {

  size(430, 570);
}

public void setup() {

  settings();

  dVal="0";

  op ="";

  left = true;

  l = 0.0f;

  r=0.0f;

  result=0.0f;

  numButtons[0] = new Button(180, 490, 50, 50, "0", true);

  numButtons[1] = new Button(100, 250, 50, 50, "1", true);

  numButtons[2] = new Button(180, 250, 50, 50, "2", true);

  numButtons[3] = new Button(260, 250, 50, 50, "3", true);

  numButtons[4] = new Button(100, 330, 50, 50, "4", true);

  numButtons[5] = new Button(180, 330, 50, 50, "5", true);

  numButtons[6] = new Button(260, 330, 50, 50, "6", true);

  numButtons[7] = new Button(100, 410, 50, 50, "7", true);

  numButtons[8] = new Button(180, 410, 50, 50, "8", true);

  numButtons[9] = new Button(260, 410, 50, 50, "9", true);

  opButtons[0] = new Button(340, 480, 80, 80, "Enter", false);

  opButtons[1] = new Button(260, 490, 50, 50, ".", false);

  opButtons[2] = new Button(340, 410, 50, 50, "/", false);

  opButtons[3] = new Button(340, 330, 50, 50, "x", false);

  opButtons[4] = new Button(340, 250, 50, 50, "-", false);

  opButtons[5] = new Button(340, 170, 50, 50, "+", false);

  opButtons[6] = new Button(260, 170, 50, 50, "x^2", false);

  opButtons[7] = new Button(180, 170, 50, 50, "sqrt", false);

  opButtons[8] = new Button(100, 170, 50, 50, "x^3", false);

  opButtons[9] = new Button(20, 170, 50, 50, "cbrt", false);

  opButtons[10] = new Button(265, 115, 100, 40, "Clear", false);
}



public void draw() {

  background(255);

  textSize(22);

  for (int i=0; i<numButtons.length; i++) {

    numButtons[i].display();

    numButtons[i].hover();
  }

  for (int i=0; i<opButtons.length; i++) {

    opButtons[i].display();

    opButtons[i].hover();
  }

  updateDisplay();
}



public void mouseReleased() {

  println("l: " + l + " r: " + r + " op: " + op);

  println("result: " + result + " left: " + left);





  for (int i=0; i<numButtons.length; i++) {

    if (numButtons[i].hover && dVal.length() <20) {

      handleEvent(numButtons[i].val, true);
    }
  }



  for (int i=0; i<opButtons.length; i++) {

    if (opButtons[i].hover) {

      handleEvent(opButtons[i].val, false);
    }
  }
}

public void updateDisplay () {

  fill(255);

  rect(10, 10, 410, 100);

  fill(0);

  textSize(22);

  text(dVal, width/2, 65);
}







public void keyPressed() {

  println ("Key" + key + "KeyCode" + keyCode);

  if (key == '0' && dVal.length() < 20) {

    handleEvent("0", true);
  } else if (key == '1'&& dVal.length() < 20) {

    handleEvent("1", true);
  } else if (key == '2'&& dVal.length() < 20) {

    handleEvent("2", true);
  } else if (key == '3'&& dVal.length() < 20) {

    handleEvent("3", true);
  } else if (key == '4'&& dVal.length() < 20) {

    handleEvent("4", true);
  } else if (key == '5'&& dVal.length() < 20) {

    handleEvent("5", true);
  } else if (key == '6'&& dVal.length() < 20) {

    handleEvent("6", true);
  } else if (key == '7'&& dVal.length() < 20) {

    handleEvent("7", true);
  } else if (key == '8'&& dVal.length() < 20) {

    handleEvent("8", true);
  } else if (key == '9'&& dVal.length() < 20) {

    handleEvent("9", true);
  } else if (key == '+') {

    handleEvent("+", false);
  } else if (key == '-') {

    handleEvent("-", false);
  } else if (key == '*') {

    handleEvent("x", false);
  } else if (key == '/') {

    handleEvent("/", false);
  } else if (key == '.') {

    handleEvent(".", false);
  } else if (key == '=') {

    handleEvent("Enter", false);
  } else if (key == 'c') {

    handleEvent("Clear", false);
  } else if (key == 's') {// press "s" for x^2 | press "b" for x^3 | press "r" for sqrt | press "t" for cbrt

    handleEvent("x^2", false);
  } else if (key == 'b') {

    handleEvent("x^3", false);
  } else if (key == 'r') {

    handleEvent("sqrt", false);
  } else if (key == 't') {

    handleEvent("cbrt", false);
  }
}





public String handleEvent(String val, boolean num) {

  if (left && num) {

    if (dVal.equals("0") || result == l) {

      dVal = (val);

      l = PApplet.parseFloat(dVal);
    } else {

      dVal += (val);

      l = PApplet.parseFloat(dVal);
    }
  } else if (!left && num) {

    if (dVal.equals("0") || result == l) {

      dVal = (val);

      r = PApplet.parseFloat(dVal);
    } else {

      dVal += (val);

      r = PApplet.parseFloat(dVal);
    }
  } else if (val.equals("Clear")) {

    dVal = "0";

    result = 0.0f;

    left = true;

    r = 0.0f;

    l = 0.0f;

    op = "";
  } else if (val.equals("+")) {

    if (!left) {

      performCalc();
    } else {

      op = "+";

      left = false;

      dVal = "0";
    }
  } else if (val.equals("-")) {

    op = "-";

    left = false;

    dVal = "0";
  } else if (val.equals("x")) {

    op = "x";

    left = false;

    dVal = "0";
  } else if (val.equals("/")) {

    op = "/";

    left = false;

    dVal = "0";
  } else if (val.equals("x^2")) {

    if (left) {

      l = sq(l);

      dVal = str(l);
    } else {

      r = sq(r);

      dVal = str(r);
    }
  } else if (val.equals("sqrt")) {

    if (left) {

      l = sqrt(l);

      dVal = str(l);
    } else {

      r = sqrt(r);

      dVal = str(r);
    }
  } else if (val.equals("x^3")) {

    if (left) {

      l = sq(l)*(l);

      dVal = str(l);
    } else {

      r = sq(r);

      dVal = str(r);
    }
  } else if (val.equals("-")) {

    if (left) {

      l *= -1;

      dVal = str(l);
    } else {

      r *= -1;

      dVal = str(r);
    }
  } else if (val.equals("cbrt")) {

    if (left) {

      l = pow(l, 0.333333333333333333333333333333333333333333333333333333333f);

      dVal = str(l);
    } else {

      r = sqrt(l)+sqrt(l)+(r);

      dVal = str(r);
    }
  } else if (val.equals(".") && !dVal.contains(".")) {

    dVal += (val);
  } else if (val.equals("Enter")) {

    performCalc();
  }

  return val;
}





public void performCalc() {

  if (op.equals("+")) {

    result = l + r;
  } else   if (op.equals("-")) {

    result = l-r;
  } else   if (op.equals("/")) {

    result = l/r;
  } else   if (op.equals("x")) {

    result = l*r;
  }

  l=result;

  dVal = str(result);

  left = true;
}
class Button {
  int x, y, w, h;
  String val;
  int c1, c2;
  boolean hover, isNumber;

  Button(int tempX, int tempY, int tempW, int tempH, String tempVal, boolean isNumber) {
    x=tempX;
    y=tempY;
    w=tempW;
    h=tempH;
    val=tempVal;
    c1=0xff4C70C6;
    c2=0xff97B0ED;
    hover=false;
    this.isNumber = isNumber;
  }
  public void display() {
    if (isNumber) {
      if (hover) {
        fill(c2);
      } else {
        fill(c1);
      }
      rect(x, y, w, h, 8);
      fill(0);
      textAlign(CENTER);
      text(val, x+w/2, y+h/2);
    } else {
      if (hover) {
        fill(c2);
      } else {
        fill(c1);
      }
      rect(x, y, w, h, 2);
      fill(0);
      textAlign(CENTER);
      text(val, x+w/2, y+h/2);
    }
  }
  public void hover() {
    hover=mouseX>x&&mouseX<x+w&&mouseY>y&&mouseY<y+h;
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "FinishCalculator" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
