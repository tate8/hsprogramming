class HealthBar:
    def __init__(self):
        self.x = 0
        self.y = 0
        self.w = 0
        self.h = 0
        # how much it goes down when hit
        self.hit_factor = 0
        
    def display(self, x, y, w, h, health, hf):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.hit_factor = hf
        fill(22, 198, 41)
        if health < 100:
            self.w -= self.hit_factor
        if health < 90:
            self.w -= self.hit_factor
        if health < 80:
            self.w -= self.hit_factor
        if health < 70:
            self.w -= self.hit_factor
        if health < 60:
            fill(240, 211, 46)
            self.w -= self.hit_factor
        if health < 50:
            self.w -= self.hit_factor
        if health < 40:
            self.w -= self.hit_factor
            fill(185, 13, 33)
        if health < 30:
            self.w -= self.hit_factor
        if health < 20:
            self.w -= self.hit_factor
        if health < 10:
            self.w = 10
        
        rect(self.x, self.y, self.w, self.h, 3)
