

class PowerUp:
    def __init__(self, img, index):
        self.type = index
        self.x = random(0, 1000)
        self.y = random(0,600)
        self.img = img
        
    def display(self):
        
        image(self.img, self.x, self.y)
