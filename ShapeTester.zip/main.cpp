#include "Box.h"
#include "Pyramid.h"
#include "Sphere.h"

#include <iostream>
using namespace std;

int what_shape_to_make;
     
int main()
{

cout << "press '1' for box, '2' for pyramid, or '3' for sphere." << endl;
cin >> what_shape_to_make;
// ----------------------BOX------------------------

if (what_shape_to_make == 1){
double length;
double width;
double height;
double volume;
double surface_area;
Box box;
    
cout << "Please Enter a Length for your box: " ;
cin >> length;
box.setLength(length);
cout << "Please Enter a Width for your box: " ;
cin >> width;
box.setWidth(width);
cout << "Please Enter a Height for your box: " ;
cin >> height;
box.setHeight(height);
volume = box.getVolume();
surface_area = box.get_surface_area();
cout << "\nThe Volume of your box is: " << volume;
cout << "\nThe Surface Area of your box is: " << surface_area;
return 0;
}
// ----------------------PYRAMID------------------------
if (what_shape_to_make == 2){
double length;
double width;
double height;
double volume;
double surface_area;
Pyramid pyramid;
    
cout << "Please Enter a Length for the base of your pyramid: " ;
cin >> length;
pyramid.setLength(length);
cout << "Please Enter a Width for the base of your pyramid: " ;
cin >> width;
pyramid.setWidth(width);
cout << "Please Enter a Height for your pyramid: " ;
cin >> height;
pyramid.setHeight(height);
volume = pyramid.getVolume();
surface_area = pyramid.get_surface_area();
cout << "\nThe Volume of your pyramid is: " << volume;
cout << "\nThe Surface Area of your pyramid is: " << surface_area;
return 0;
}
// ----------------------Sphere------------------------

if (what_shape_to_make == 3){
double radius;
double volume;
double surface_area;
Sphere sphere;
    
cout << "Please Enter a radius for your sphere: " ;
cin >> radius;
sphere.setLength(radius);

volume = sphere.getVolume();
surface_area = sphere.get_surface_area();
cout << "\nThe Volume of your sphere is: " << volume;
cout << "\nThe Surface Area of your sphere is: " << surface_area;
return 0;
}
}