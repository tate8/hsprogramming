#include <iostream>
#include <cmath>
using namespace std;

class Sphere
{
    public:
double radius;
//Declare Member functions
double getVolume(void);
double get_surface_area(void);
string getParameters(void);
void setLength(double leng);

double getLength(double radius);

};//end class 

//member function definitions

double Sphere::getVolume(void)//get volume will cal and output the volume when called
{
return 1.3333333333*3.141596*pow(3.0, radius);
}
double Sphere::get_surface_area(void)
{
return 4*3.1415926*pow(2.0,radius);
}
void Sphere::setLength(double leng)
{
radius = leng;
}
double Sphere::getLength(double radius)
{
return radius;
}
