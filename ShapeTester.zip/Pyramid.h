#include <iostream>

using namespace std;

class Pyramid
{
    public:
double length;//length of the box
double height;//height of the box
double width;//with of the box
//Declare Member functions
double getVolume(void);
double get_surface_area(void);
string getParameters(void);
void setLength(double leng);
void setWidth(double wid);
void setHeight(double hei);
double getLength(double length);
double getWidth(double width );
double getHeight(double height);
};//end class 

//member function definitions

double Pyramid::getVolume(void)//get volume will cal and output the volume when called
{
return length*width * height * 0.33333333333;
}
double Pyramid::get_surface_area(void)
{
return length*width+0.5*width*height*2+0.5*length*height*2;
}
void Pyramid::setLength(double leng)
{
length = leng;
}
double Pyramid::getLength(double length)
{
return length;
}
void Pyramid::setWidth(double wid)
{
width = wid;
}
double Pyramid::getWidth(double width)
{
return width;
}
void Pyramid::setHeight(double hei)
{
height = hei;
}
double Pyramid::getHeight(double height)
{
return height;
}